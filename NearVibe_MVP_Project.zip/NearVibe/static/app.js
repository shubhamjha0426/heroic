document.addEventListener("DOMContentLoaded", () => {
  const dateInput = document.querySelector('input[name="event_date"]');
  if (dateInput && !dateInput.value) {
    // Do not force a date: organizers choose the actual event date.
  }
  document.querySelectorAll(".flash").forEach((el) => {
    window.setTimeout(() => { el.style.transition = "opacity .35s"; el.style.opacity = "0.94"; }, 4500);
  });
});
