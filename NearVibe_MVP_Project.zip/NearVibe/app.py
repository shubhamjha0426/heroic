from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3, os
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "nearvibe-dev-key-change-me")
DB_PATH = os.path.join(os.path.dirname(__file__), "nearvibe.db")

SAMPLE_EVENTS = [
    ("Mumbai Student Hack Night", "Technology", "2026-10-25", "10:00", "Mira Road", "Free", "Build a useful prototype with other student makers. Bring your laptop and curiosity.", "Shree L.R. Tiwari area", 19.2813, 72.8560, "CodeCrew", 38),
    ("AI for Everyday Projects", "Workshop", "2026-10-26", "14:00", "Thane", "₹199", "A beginner-friendly workshop exploring practical AI tools and responsible use.", "Thane Station area", 19.2183, 72.9781, "FutureLab", 24),
    ("Community Football Meetup", "Sports", "2026-10-27", "17:30", "Kandivali", "Free", "Meet local players, make teams, and enjoy a friendly evening match.", "Kandivali West", 19.2043, 72.8526, "PlayLocal", 31),
    ("Design Jam: Make It Accessible", "Design", "2026-10-28", "11:00", "Bandra", "Free", "A collaborative design sprint focused on making digital experiences more inclusive.", "Bandra Kurla area", 19.0600, 72.8360, "DesignCircle", 19),
    ("Founders & Chai Meetup", "Networking", "2026-10-29", "18:00", "Andheri", "₹99", "An informal networking evening for students, early builders, and aspiring founders.", "Andheri East", 19.1197, 72.8468, "MumbaiBuilds", 42),
    ("Open Mic Under the Stars", "Music", "2026-10-30", "19:00", "Borivali", "₹150", "Share poetry, music, comedy, or just come along to support local performers.", "Borivali West", 19.2307, 72.8567, "StageSide", 27),
]

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            event_date TEXT NOT NULL,
            event_time TEXT NOT NULL,
            area TEXT NOT NULL,
            price TEXT NOT NULL DEFAULT 'Free',
            description TEXT NOT NULL,
            venue TEXT NOT NULL,
            latitude REAL,
            longitude REAL,
            organizer TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
            attendee_name TEXT NOT NULL,
            attendee_email TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(event_id, attendee_email)
        );
        CREATE TABLE IF NOT EXISTS saved_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
            attendee_email TEXT NOT NULL,
            UNIQUE(event_id, attendee_email)
        );
        """)
        count = con.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        if count == 0:
            con.executemany("""INSERT INTO events
                (title,category,event_date,event_time,area,price,description,venue,latitude,longitude,organizer)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", SAMPLE_EVENTS)

@app.route("/")
def index():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    area = request.args.get("area", "").strip()
    with connect() as con:
        sql = """SELECT e.*, (SELECT COUNT(*) FROM registrations r WHERE r.event_id=e.id) AS attendee_count
                 FROM events e WHERE 1=1"""
        params = []
        if q:
            sql += " AND (e.title LIKE ? OR e.description LIKE ? OR e.organizer LIKE ?)"
            params += [f"%{q}%"] * 3
        if category:
            sql += " AND e.category=?"
            params.append(category)
        if area:
            sql += " AND e.area LIKE ?"
            params.append(f"%{area}%")
        sql += " ORDER BY e.event_date, e.event_time"
        events = con.execute(sql, params).fetchall()
        categories = [r["category"] for r in con.execute("SELECT DISTINCT category FROM events ORDER BY category")]
        areas = [r["area"] for r in con.execute("SELECT DISTINCT area FROM events ORDER BY area")]
        stats = {
            "events": con.execute("SELECT COUNT(*) FROM events").fetchone()[0],
            "registrations": con.execute("SELECT COUNT(*) FROM registrations").fetchone()[0],
            "areas": con.execute("SELECT COUNT(DISTINCT area) FROM events").fetchone()[0],
        }
    return render_template("index.html", events=events, categories=categories, areas=areas,
                           q=q, selected_category=category, selected_area=area, stats=stats)

@app.route("/event/<int:event_id>")
def event_detail(event_id):
    with connect() as con:
        event = con.execute("""SELECT e.*, (SELECT COUNT(*) FROM registrations r WHERE r.event_id=e.id) AS attendee_count
                               FROM events e WHERE e.id=?""", (event_id,)).fetchone()
    if not event:
        flash("That event could not be found.", "error")
        return redirect(url_for("index"))
    return render_template("event.html", event=event)

@app.route("/event/<int:event_id>/register", methods=["POST"])
def register(event_id):
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    if not name or "@" not in email or "." not in email.split("@")[-1]:
        flash("Enter your name and a valid email address.", "error")
        return redirect(url_for("event_detail", event_id=event_id))
    try:
        with connect() as con:
            exists = con.execute("SELECT id FROM events WHERE id=?", (event_id,)).fetchone()
            if not exists:
                flash("Event not found.", "error")
                return redirect(url_for("index"))
            con.execute("INSERT INTO registrations(event_id, attendee_name, attendee_email) VALUES(?,?,?)",
                        (event_id, name, email))
        flash("You're on the list! Your registration is saved.", "success")
    except sqlite3.IntegrityError:
        flash("This email is already registered for this event.", "error")
    return redirect(url_for("event_detail", event_id=event_id))

@app.route("/event/<int:event_id>/save", methods=["POST"])
def save_event(event_id):
    email = request.form.get("email", "").strip().lower()
    if "@" not in email:
        flash("Enter a valid email to save this event.", "error")
        return redirect(url_for("event_detail", event_id=event_id))
    try:
        with connect() as con:
            con.execute("INSERT INTO saved_events(event_id, attendee_email) VALUES(?,?)", (event_id, email))
        flash("Event saved to your shortlist.", "success")
    except sqlite3.IntegrityError:
        flash("This event is already in that email's shortlist.", "error")
    return redirect(url_for("event_detail", event_id=event_id))

@app.route("/organizer", methods=["GET", "POST"])
def organizer():
    if request.method == "POST":
        fields = {k: request.form.get(k, "").strip() for k in
                  ["title", "category", "event_date", "event_time", "area", "price", "description", "venue", "organizer"]}
        if any(not fields[k] for k in ["title", "category", "event_date", "event_time", "area", "description", "venue", "organizer"]):
            flash("Please complete all required fields.", "error")
            return redirect(url_for("organizer"))
        try:
            datetime.strptime(fields["event_date"], "%Y-%m-%d")
        except ValueError:
            flash("Choose a valid event date.", "error")
            return redirect(url_for("organizer"))
        with connect() as con:
            con.execute("""INSERT INTO events(title,category,event_date,event_time,area,price,description,venue,organizer)
                           VALUES(?,?,?,?,?,?,?,?,?)""",
                        (fields["title"], fields["category"], fields["event_date"], fields["event_time"],
                         fields["area"], fields["price"] or "Free", fields["description"], fields["venue"], fields["organizer"]))
        flash("Event published successfully.", "success")
        return redirect(url_for("organizer"))
    with connect() as con:
        events = con.execute("""SELECT e.*, COUNT(r.id) AS attendee_count
                                FROM events e LEFT JOIN registrations r ON r.event_id=e.id
                                GROUP BY e.id ORDER BY e.created_at DESC""").fetchall()
        total_reg = con.execute("SELECT COUNT(*) FROM registrations").fetchone()[0]
        total_saved = con.execute("SELECT COUNT(*) FROM saved_events").fetchone()[0]
    return render_template("organizer.html", events=events, total_reg=total_reg, total_saved=total_saved)

@app.route("/api/events")
def api_events():
    with connect() as con:
        rows = con.execute("SELECT id,title,category,event_date,event_time,area,price,venue,organizer FROM events ORDER BY event_date").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/health")
def health():
    return jsonify({"status": "ok", "app": "NearVibe"})

if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=int(os.environ.get("PORT", 5000)))
else:
    init_db()
