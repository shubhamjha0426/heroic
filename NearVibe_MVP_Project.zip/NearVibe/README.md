# NearVibe — Hyperlocal Event Discovery & Community Engagement

**Tagline:** Find your people. Discover your next experience.

NearVibe is a hackathon MVP for discovering local events and helping organizers reach an interested community. It includes searchable events, category/neighbourhood filters, event detail pages, registrations, saved-event shortlists, and an organizer dashboard.

## MVP features
- Browse events with demo seed data
- Search by event title, description, or organizer
- Filter by category and neighbourhood
- View event date, time, venue, host, price, and registration count
- Register with name + email; duplicate email registrations are blocked
- Save an event to a shortlist using email
- Publish an event from Organizer Studio
- View organizer overview counts
- JSON endpoint at `/api/events` and health check at `/health`
- Responsive desktop/mobile layout

## Tech stack
- Python + Flask
- SQLite
- HTML templates, CSS, JavaScript
- Git + GitHub

## Run locally (Windows / VS Code)
1. Install Python 3.10+ from https://www.python.org/downloads/ and tick **Add Python to PATH**.
2. Open this folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment:
   ```powershell
   py -m venv .venv
   ```
5. Activate it:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks activation, use Command Prompt terminal and run:
   ```bat
   .venv\Scripts\activate.bat
   ```
6. Install dependencies:
   ```powershell
   python -m pip install -r requirements.txt
   ```
7. Start the app:
   ```powershell
   python app.py
   ```
8. Open **http://127.0.0.1:5000** in your browser.

The SQLite database (`nearvibe.db`) is created automatically and seeded with sample events on first run. Delete the database file to reset demo data (stop the app first).

## Demo flow for judges (2–3 minutes)
1. Open homepage and explain the scattered-event-discovery problem.
2. Search for `AI` and filter by category or neighbourhood.
3. Open an event and register using test data such as `Demo User` and `demo@example.com`.
4. Show that the registration count updates.
5. Save an event using `demo@example.com` (or a different test email).
6. Open **For organizers → Host an event**, publish a new event, and show it on the organizer overview and Discover page.
7. Open `/api/events` to show the JSON endpoint and `/health` to show status.
8. Explain that the next phase could add browser geolocation, verified organizers, reminders, maps, and smarter interest-based ranking.

## GitHub publish (Public repository)
In the VS Code terminal, from this folder:
```bash
git init
git add .
git commit -m "Build NearVibe hackathon MVP"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/NearVibe.git
git push -u origin main
```
Create the repository on GitHub first and set visibility to **Public**. Replace `YOUR-USERNAME` with your GitHub username. If Git asks you to authenticate, complete the browser sign-in prompt. Never commit passwords, API keys, or real attendee information.

If Git says `remote origin already exists`, run:
```bash
git remote set-url origin https://github.com/YOUR-USERNAME/NearVibe.git
```

## Deployment (optional, recommended)
Use a Python-capable host such as Render. Set:
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Environment variable: `SECRET_KEY` = a long random value

Important: SQLite is suitable for a hackathon demo but may not persist on every host's temporary filesystem. For a deployed demo that must retain data across restarts, configure a persistent disk or use a managed database. Do not use real personal data in the public demo.

## Current limitations / honest demo notes
- Sample event locations and attendee counts are illustrative; the listed counts are seed/demo information, not verified live attendance.
- The MVP uses manually selected neighbourhoods, not automatic GPS geolocation.
- Authentication, organizer verification, email notifications, payments, QR scanning, and production security are not implemented yet.
- The event "joined" count comes from actual registrations in the local database; the sample seed data does not fake registrations.
- Do not describe recommendation logic as AI. Interest matching is planned as a next step.

## Team split (2–4 people)
- Member 1: UI/UX, responsive testing, screenshots
- Member 2: Flask routes, database, registration testing
- Member 3: PPT, demo script, README, GitHub repository
- Member 4 (if available): testing, deployment, feature backlog
